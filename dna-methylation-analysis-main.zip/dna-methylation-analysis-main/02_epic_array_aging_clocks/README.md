# Analysis 2 — EPIC Array Epigenetic Aging Clock Benchmarking

Benchmarking of eight epigenetic aging clocks across two independent whole-blood Illumina EPIC array datasets using the **Biolearn** Python library. Analysis conducted on **Google Colab**.

---

## Table of Contents

- [Biological Rationale](#biological-rationale)
- [Datasets](#datasets)
- [Aging Clocks](#aging-clocks)
- [Methods](#methods)
- [Results and Interpretation](#results-and-interpretation)
- [Summary](#summary)
- [References](#references)

---

## Biological Rationale

### Epigenetic Clocks

Epigenetic clocks are multivariate regression models that estimate biological age from DNA methylation data. Their theoretical basis rests on the observation that methylation levels at specific CpG sites change with age in a highly consistent, tissue-specific, and partially heritable manner. By training elastic net or similar penalised regression models on methylation profiles from individuals of known chronological age, it is possible to construct predictors that estimate age with mean absolute errors of 3–5 years from blood alone.

The biological significance of epigenetic clocks lies in the divergence between estimated biological age and chronological age — termed **epigenetic age acceleration**. Positive acceleration (biological age > chronological age) has been associated with increased all-cause mortality, cardiovascular disease, cancer risk, cognitive decline, and accelerated cellular senescence. Negative acceleration has been associated with healthy aging phenotypes and longevity.

Different clocks capture different biological dimensions:

- **First-generation clocks** (Horvathv1, Hannum, Lin) were trained directly on chronological age and primarily reflect developmental and age-related methylation drift
- **Second-generation clocks** (PhenoAge, GrimAge) were trained on composite clinical biomarkers or mortality risk, better capturing health-related aging components
- **Pace-of-aging clocks** (DunedinPACE) measure the rate at which biological systems are declining, rather than a static age estimate
- **Minimal clocks** (Zhang_10) reduce the CpG set to the minimum required for feasible clinical application

Benchmarking these clocks on the same datasets allows direct comparison of their agreement, accuracy, and conceptual differences.

### The EPIC Array

The Illumina EPIC (850K) methylation array simultaneously measures DNA methylation at approximately 850,000 CpG sites genome-wide using bisulfite conversion followed by hybridisation to bead-chip arrays. Each CpG is reported as a beta value (β) ranging from 0 (fully unmethylated) to 1 (fully methylated). The EPIC array is the standard platform for population-scale epigenetic aging studies and underlies the training and validation of all clocks used here.

---

## Datasets

Two publicly available whole-blood EPIC array datasets were accessed from NCBI GEO through the Biolearn data library:

| Dataset | GEO Accession | N Samples | Age Range | Description |
|---------|--------------|-----------|-----------|-------------|
| Dataset 1 | **GSE120307** | 34 | Adults | Whole blood EPIC array, healthy donors |
| Dataset 2 | **GSE41169** | 95 | Adults | Whole blood EPIC array, healthy donors |

Using two independent datasets enables assessment of whether observed patterns (clock correlations, age deviations, MAE rankings) are robust and reproducible rather than dataset-specific.

---

## Aging Clocks

Eight aging clocks from the Biolearn model gallery were applied to both datasets:

| Clock | First Author | Year | N CpGs | Training Phenotype | Generation |
|-------|-------------|------|--------|-------------------|------------|
| **Horvathv1** | Horvath | 2013 | 353 | Chronological age (pan-tissue) | 1st |
| **Hannum** | Hannum | 2013 | 71 | Chronological age (blood) | 1st |
| **Lin** | Lin | 2016 | 99 | Chronological age (blood) | 1st |
| **PhenoAge** | Levine | 2018 | 513 | Composite clinical biomarkers | 2nd |
| **GrimAge** | Lu | 2019 | ~1000 | Mortality risk / DNAm surrogates | 2nd |
| **DunedinPACE** | Belsky | 2022 | 173 | Longitudinal pace of physiological decline | Pace |
| **Zhang_10** | Zhang | 2019 | 10 | Chronological age (minimal CpG set) | Minimal |
| **HRSInChPhenoAge** | Crimmins | 2022 | 513 | Phenotypic age (Health and Retirement Study) | 2nd |

**Note on DunedinPACE:** Unlike all other clocks, DunedinPACE does not predict age in years. It outputs a dimensionless pace-of-aging score (mean = 1.0 in the training cohort), where values above 1.0 indicate faster-than-average biological aging. Correlation with chronological age clocks is not expected and near-zero or negative correlations are biologically interpretable rather than indicative of poor performance.

---

## Methods

### Data Loading

```python
from biolearn.data_library import GeoData
from biolearn.model_gallery import ModelGallery

data1 = GeoData.load("GSE120307")
data2 = GeoData.load("GSE41169")
```

### Clock Prediction

```python
gallery = ModelGallery()

clocks = ["Horvathv1", "Hannum", "Lin", "PhenoAge", 
          "GrimAge", "DunedinPACE", "Zhang_10", "HRSInChPhenoAge"]

results1, results2 = {}, {}
for clock in clocks:
    model = gallery.get(clock)
    results1[clock] = model.predict(data1).predicted_age
    results2[clock] = model.predict(data2).predicted_age

df1 = pd.DataFrame(results1)
df2 = pd.DataFrame(results2)
```

For the complete annotated notebook, see [`aging_clock_benchmarking.ipynb`](./aging_clock_benchmarking.ipynb).

---

## Results and Interpretation

### Figure 01 — Clock Correlation Matrix, GSE120307

![Correlation Matrix GSE120307](./figures/01_correlation_matrix_GSE120307.png)

*Pearson correlation matrix of clock predictions across 34 samples (GSE120307). First-generation chronological clocks (Horvathv1, Hannum, Lin) cluster together with pairwise correlations exceeding r = 0.90, reflecting their shared training objective of chronological age. Second-generation clocks (PhenoAge, GrimAge, HRSInChPhenoAge) show moderate-to-high correlations with first-generation clocks (r = 0.70–0.85) but diverge from each other, reflecting different training phenotypes. DunedinPACE shows near-zero or negative correlations with all other clocks, consistent with its fundamentally different design as a pace-of-aging rather than age-prediction instrument.*

---

### Figure 02 — Clock Correlation Matrix, GSE41169

![Correlation Matrix GSE41169](./figures/02_correlation_matrix_GSE41169.png)

*Pearson correlation matrix for 95 samples (GSE41169). The same broad clustering structure is retained — first-generation clocks remain strongly correlated, and DunedinPACE remains orthogonal. Overall correlations are modestly lower than in GSE120307, consistent with greater biological heterogeneity in the larger cohort and the wider age range increasing variance. The reproducibility of the correlation structure across both datasets confirms that observed patterns reflect true clock properties rather than sampling artefacts.*

---

### Figure 03 — Age Deviation Heatmap, GSE120307

![Age Deviation Heatmap GSE120307](./figures/03_age_deviation_heatmap_GSE120307.png)

*Heatmap of epigenetic age deviation (predicted age − chronological age) per sample per clock, GSE120307 (34 samples). Each row is a clock; each column is a sample. Red cells indicate the clock predicts an older biological age than chronological age (positive acceleration); blue cells indicate younger predicted age. Most clocks stay within ±10 years of chronological age for the majority of samples. DunedinPACE and Zhang_10 display the most extreme deviations, reflecting their non-standard prediction targets and limited CpG sets, respectively. Several samples show consistent multi-clock acceleration or deceleration patterns across multiple first- and second-generation clocks simultaneously, suggesting genuine biological age differences rather than random clock noise.*

---

### Figure 04 — Age Deviation Heatmap, GSE41169

![Age Deviation Heatmap GSE41169](./figures/04_age_deviation_heatmap_GSE41169.png)

*Age deviation heatmap for GSE41169 (95 samples). With a larger cohort, within-sample agreement across multiple clocks is more clearly visible. Clusters of samples with concordant acceleration or deceleration across several clocks are apparent, supporting the interpretation that inter-individual biological age variation is being captured. The broader deviation range compared to GSE120307 reflects the wider chronological age range in this dataset.*

---

### Figure 05 — Predicted vs Chronological Age, GSE120307

![Predicted vs Chronological Age GSE120307](./figures/05_predicted_vs_chronological_age_GSE120307.png)

*Scatter plots of predicted age vs chronological age for each clock, GSE120307. The red dashed diagonal represents perfect prediction (predicted = chronological). Clocks whose points cluster tightly around this line have low prediction error. Horvathv1 and Hannum track chronological age most closely. PhenoAge and GrimAge show slight systematic deviations reflecting their training on biological rather than chronological phenotypes. Zhang_10 shows poor tracking due to its minimal CpG set. DunedinPACE points form a horizontal band consistent with its dimensionless pace-of-aging output.*

---

### Figure 06 — Predicted vs Chronological Age, GSE41169

![Predicted vs Chronological Age GSE41169](./figures/06_predicted_vs_chronological_age_GSE41169.png)

*Corresponding scatter plots for GSE41169 (95 samples). The broader age range in this dataset improves the visual discrimination of clocks by prediction accuracy. Horvathv1 maintains strong tracking of chronological age across the full age range. The poor performance of Zhang_10 is more apparent with increased sample size, with many predictions diverging substantially from the diagonal.*

---

### Figure 07 — Mean Absolute Error Comparison

![MAE Comparison](./figures/07_mean_absolute_error_comparison.png)

*Mean Absolute Error (MAE, years) per clock across both datasets. Horvathv1 achieves the lowest MAE (~4 years) on both datasets, consistent with its status as the most thoroughly validated pan-tissue chronological age predictor. Hannum and Lin also perform well (~5–7 years). PhenoAge and GrimAge show higher MAE (~8–12 years), which is expected given they were not optimised for chronological age prediction. Zhang_10 achieves by far the highest MAE (~38 years on GSE120307), illustrating the substantial accuracy cost of compressing a clock to only 10 CpGs. DunedinPACE MAE is not directly interpretable in years given its non-age output.*

---

### Figure 08 — Predicted Age Distributions

![Predicted Age Distributions](./figures/08_predicted_age_distributions.png)

*Box plots of predicted age distributions per clock. First-generation and second-generation clocks produce predicted age distributions broadly centred on the mean chronological age of each cohort, as expected for well-calibrated predictors. Zhang_10 is a clear outlier with a median prediction near zero on GSE120307, indicating severe miscalibration on this dataset. DunedinPACE shows a compressed distribution near 1.0 (its expected mean), confirming its distinct output scale.*

---

## Summary

| Metric | Best Performer | Worst Performer | Key Observation |
|--------|---------------|-----------------|-----------------|
| Chronological age accuracy (MAE) | Horvathv1 (~4 yr) | Zhang_10 (~38 yr) | CpG count strongly influences accuracy |
| Inter-clock agreement | Horvathv1, Hannum, Lin (r > 0.90) | DunedinPACE | DunedinPACE is conceptually orthogonal |
| Age deviation range | Lin, Hannum (±10 yr) | Zhang_10, DunedinPACE | Larger deviations in non-chronological clocks |
| Cross-dataset reproducibility | All first/second-gen clocks | — | Clock behaviour is consistent across datasets |

The benchmarking demonstrates that first-generation chronological clocks (particularly Horvathv1) remain the most accurate predictors of chronological age in blood, while second-generation clocks capture complementary biological aging dimensions at the cost of increased chronological prediction error. DunedinPACE provides unique and orthogonal information about aging pace not captured by static age-prediction clocks. Zhang_10 illustrates the trade-off between clinical minimalism and prediction accuracy.

---

## References

- Ying, K. et al. (2023). Biolearn, an open-source library for biomarkers of aging. *bioRxiv*. https://doi.org/10.1101/2023.12.02.569722
- Horvath, S. (2013). DNA methylation age of human tissues and cell types. *Genome Biology*, 14, R115. https://doi.org/10.1186/gb-2013-14-10-r115
- Hannum, G. et al. (2013). Genome-wide methylation profiles reveal quantitative views of human aging rates. *Molecular Cell*, 49(2), 359–367. https://doi.org/10.1016/j.molcel.2012.10.016
- Levine, M.E. et al. (2018). An epigenetic biomarker of aging for lifespan and healthspan. *Aging*, 10(4), 573–591. https://doi.org/10.18632/aging.101414
- Lu, A.T. et al. (2019). DNA methylation GrimAge strongly predicts lifespan and healthspan. *Aging*, 11(2), 303–327. https://doi.org/10.18632/aging.101684
- Belsky, D.W. et al. (2022). DunedinPACE, a DNA methylation biomarker of the pace of aging. *eLife*, 11, e73420. https://doi.org/10.7554/eLife.73420
- Biolearn documentation: https://bio-learn.github.io/
