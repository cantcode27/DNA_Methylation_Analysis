# DNA Methylation Analysis: WGBS Breast Cancer Methylomes and Epigenetic Clock Benchmarking

<div align="center">

[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![Platform: Galaxy Europe](https://img.shields.io/badge/Platform-Galaxy%20Europe-brightgreen)](https://usegalaxy.eu)
[![Platform: Google Colab](https://img.shields.io/badge/Platform-Google%20Colab-orange)](https://colab.research.google.com)
[![Language: Python 3](https://img.shields.io/badge/Language-Python%203-blue)](https://www.python.org)
[![Array: Illumina EPIC 850K](https://img.shields.io/badge/Array-Illumina%20EPIC%20850K-purple)]()
[![Reference: hg38](https://img.shields.io/badge/Genome-hg38%20GRCh38-red)]()
[![Open in Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/pukhraj-tahir/dna-methylation-analysis/blob/main/02_epic_array_aging_clocks/aging_clock_benchmarking.ipynb)

</div>

---

## Overview

This repository documents two complementary, fully reproducible analyses of DNA methylation data that together span two major domains of epigenomics: cancer biology and aging biology.

**Analysis 1** applies a complete whole-genome bisulfite sequencing (WGBS) pipeline to breast cancer and normal breast tissue samples from [Lin et al. (2015)](https://doi.org/10.1371/journal.pone.0118453), executed on Galaxy Europe. The pipeline recapitulates the key epigenomic hallmarks of invasive ductal carcinoma — aberrant promoter hypermethylation and global hypomethylation — at single-base resolution.

**Analysis 2** benchmarks eight established epigenetic aging clocks across two independent Illumina EPIC array whole-blood datasets using the [Biolearn](https://bio-learn.github.io/) Python library, evaluating their accuracy, inter-clock agreement, and age prediction characteristics. Clocks range from the original 2013 Horvath pan-tissue predictor to second-generation mortality-risk models and a longitudinal pace-of-aging instrument.

Both analyses are documented with full biological rationale, step-by-step methodology, figure-by-figure result interpretation, and reproducibility instructions.

---

## Table of Contents

- [Repository Structure](#repository-structure)
- [Scientific Background](#scientific-background)
  - [DNA Methylation](#dna-methylation)
  - [Methylation in Cancer](#methylation-in-cancer)
  - [Epigenetic Clocks](#epigenetic-clocks)
- [Analysis 1 — WGBS Breast Cancer Pipeline](#analysis-1--wgbs-breast-cancer-pipeline)
  - [Dataset](#dataset)
  - [Pipeline](#pipeline)
  - [Results with Interpretations](#results-with-interpretations)
  - [Summary of Findings](#wgbs-summary-of-findings)
- [Analysis 2 — Epigenetic Clock Benchmarking](#analysis-2--epigenetic-clock-benchmarking)
  - [Datasets](#datasets)
  - [Clocks Benchmarked](#clocks-benchmarked)
  - [Methods](#methods)
  - [Results with Interpretations](#clock-results-with-interpretations)
  - [Summary of Findings](#clock-summary-of-findings)
- [How to Reproduce](#how-to-reproduce)
- [Dependencies](#dependencies)
- [Citations](#citations)

---

## Repository Structure

```
dna-methylation-analysis/
│
├── 01_wgbs_breast_cancer/
│   ├── README.md                                    ← Full pipeline walkthrough and interpretation
│   └── figures/
│       ├── 01_qc_read1_sequence_content.png         ← Falco QC: Read 1 bisulfite conversion
│       ├── 02_qc_read2_sequence_content.png         ← Falco QC: Read 2 bisulfite conversion
│       ├── 03_methylation_bias_top_strand.png       ← MethylDackel mbias: positional bias check
│       ├── 04_methylation_profile_single_sample.png ← plotProfile: single sample TSS profile
│       ├── 05_methylation_profile_all_samples.png   ← plotProfile: all 6 samples compared
│       ├── 06_dmr_methylation_difference_distribution.png
│       ├── 07_dmr_length_nucleotides.png
│       ├── 08_dmr_length_cpg_count.png
│       ├── 09_dmr_qvalue_vs_difference.png
│       ├── 10_dmr_group1_vs_group2_methylation.png
│       └── 11_dmr_length_nt_vs_cpg.png
│
├── 02_epic_array_aging_clocks/
│   ├── aging_clock_benchmarking.ipynb               ← Fully annotated analysis notebook
│   ├── README.md                                    ← Full methodology and result interpretation
│   └── figures/
│       ├── 01_correlation_matrix_GSE120307.png      ← Clock correlations, Dataset 1
│       ├── 02_correlation_matrix_GSE41169.png       ← Clock correlations, Dataset 2
│       ├── 03_age_deviation_heatmap_GSE120307.png   ← Age deviation per sample, Dataset 1
│       ├── 04_age_deviation_heatmap_GSE41169.png    ← Age deviation per sample, Dataset 2
│       ├── 05_predicted_vs_chronological_age_GSE120307.png
│       ├── 06_predicted_vs_chronological_age_GSE41169.png
│       ├── 07_mean_absolute_error_comparison.png    ← MAE across all 8 clocks
│       └── 08_predicted_age_distributions.png       ← Box plots of clock predictions
│
├── LICENSE
└── README.md                                        ← This file
```

---

## Scientific Background

### DNA Methylation

DNA methylation is a covalent epigenetic modification in which a methyl group (–CH₃) is added to the 5-carbon position of cytosine residues, predominantly at CpG dinucleotides, catalysed by DNA methyltransferase (DNMT) enzymes. It is one of the most extensively characterised epigenetic marks in mammalian biology, with well-established roles in:

- Transcriptional regulation (promoter CpG island methylation → gene silencing)
- Genomic imprinting and X-chromosome inactivation
- Maintenance of genome stability via silencing of repetitive elements
- Embryonic development and cellular differentiation

The key technology enabling genome-wide single-base resolution methylation measurement is **bisulfite sequencing**. Bisulfite treatment chemically converts unmethylated cytosines to uracil (read as thymine after PCR), while methylated cytosines are protected from conversion and read as cytosine. Comparing C vs T calls at each CpG position therefore reconstructs the methylation state of every cytosine in the genome.

### Methylation in Cancer

In cancer, the normal methylation landscape is profoundly disrupted in two coordinated but opposing ways:

| Change | Location | Consequence |
|--------|----------|-------------|
| **Focal hypermethylation** | Promoter CpG islands of tumour suppressors | Transcriptional silencing — equivalent to mutation in loss-of-function effect |
| **Global hypomethylation** | Gene bodies, repetitive elements, large PMDs | Genomic instability, aberrant gene activation, transposon derepression |

Lin et al. (2015) characterised these changes at single-base resolution in breast cancer using WGBS, identifying tumour-specific hypomethylated region (HMR) clusters, differentially methylated enhancers, and methylation-driven gene expression changes including effects on X-chromosome inactivation.

### Epigenetic Clocks

Epigenetic clocks are multivariate regression models that predict biological age from DNA methylation data. They exploit the observation that methylation levels at specific CpG loci change with age in a highly consistent, partially heritable manner across individuals. By training penalised regression models on methylation profiles from donors of known age, predictors can be built that estimate age with mean absolute errors of 3–5 years from blood alone.

The scientific significance lies in **epigenetic age acceleration** — the divergence between estimated biological age and chronological age. Positive acceleration has been associated with increased all-cause mortality, cardiovascular disease, cancer risk, cognitive decline, and accelerated cellular senescence. Negative acceleration is associated with healthy aging phenotypes.

Different clocks capture different aspects of biological aging:

| Generation | Examples | Training Target | What It Captures |
|------------|----------|-----------------|------------------|
| 1st generation | Horvathv1, Hannum, Lin | Chronological age | Developmental and age-related methylation drift |
| 2nd generation | PhenoAge, GrimAge | Biological phenotypes / mortality | Health-relevant aging components |
| Pace-of-aging | DunedinPACE | Longitudinal physiological decline | Rate of biological system deterioration |
| Minimal | Zhang_10 | Chronological age (10 CpGs) | Clinical feasibility trade-off |

---

## Analysis 1 — WGBS Breast Cancer Pipeline

**Platform:** Galaxy Europe (`usegalaxy.eu`)  
**Reference dataset:** Lin et al. (2015) — ArrayExpress accession **E-MTAB-2014**  
**Reference genome:** hg38 (GRCh38), chromosome 6 subset  
**Full documentation:** [`01_wgbs_breast_cancer/README.md`](./01_wgbs_breast_cancer/README.md)

### Dataset

Six samples spanning normal breast tissue and invasive ductal carcinoma were analysed:

| Sample ID | Tissue Type | Experimental Group |
|-----------|-------------|-------------------|
| NB1 | Normal breast | Control |
| NB2 | Normal breast | Control |
| BT089 | Invasive ductal carcinoma | Case |
| BT126 | Invasive ductal carcinoma | Case |
| BT198 | Invasive ductal carcinoma | Case |
| MCF7 | Breast cancer cell line | Case |

### Pipeline

Each step is listed with its tool, version, and biological purpose:

```
Raw FASTQ Reads (paired-end bisulfite-treated)
         │
         ▼
  ┌──────────────────────────────────────────────────┐
  │  Step 1 — Quality Control                        │
  │  Tool: Falco v1.2.4                              │
  │  Purpose: Verify bisulfite conversion; assess    │
  │  read quality before alignment                   │
  └──────────────────────────────────────────────────┘
         │
         ▼
  ┌──────────────────────────────────────────────────┐
  │  Step 2 — Bisulfite-Aware Alignment              │
  │  Tool: bwameth v0.2.7 → hg38                    │
  │  Purpose: Align C→T/G→A converted reads without │
  │  introducing systematic mismatch artefacts       │
  └──────────────────────────────────────────────────┘
         │
         ▼
  ┌──────────────────────────────────────────────────┐
  │  Step 3 — Methylation Extraction + Bias Check    │
  │  Tool: MethylDackel v0.5.2                       │
  │  Purpose: Call per-CpG methylation from BAM;     │
  │  detect and exclude positional bias              │
  └──────────────────────────────────────────────────┘
         │
         ▼
  ┌──────────────────────────────────────────────────┐
  │  Step 4 — Methylation Profiling                  │
  │  Tools: computeMatrix + plotProfile v3.5.4       │
  │  Purpose: Visualise methylation around CpG       │
  │  islands and TSS across all samples              │
  └──────────────────────────────────────────────────┘
         │
         ▼
  ┌──────────────────────────────────────────────────┐
  │  Step 5 — DMR Detection                          │
  │  Tool: Metilene v0.2.6.1                         │
  │  Purpose: Identify statistically significant     │
  │  differentially methylated regions between       │
  │  normal and tumour groups                        │
  └──────────────────────────────────────────────────┘
         │
         ▼
  Output: bedGraph methylation files, DMR tables,
  methylation profiles, QC reports
```

### Results with Interpretations

---

#### Figure 1 — Per-base sequence content, Read 1 (Falco QC)

![QC Read 1](./01_wgbs_breast_cancer/figures/01_qc_read1_sequence_content.png)

**What this shows:** Per-base nucleotide frequency across all positions of Read 1.

**Interpretation:** Cytosine (C) frequency drops to approximately 0% and thymine (T) rises to approximately 50% uniformly across all read positions. This is not a quality defect — it is the expected and required signature of successful bisulfite conversion. Unmethylated cytosines have been quantitatively deaminated to uracil, amplified as thymine, confirming that the bisulfite treatment was complete before sequencing. A failure to convert would manifest as elevated C levels and would invalidate all downstream methylation calls.

---

#### Figure 2 — Per-base sequence content, Read 2 (Falco QC)

![QC Read 2](./01_wgbs_breast_cancer/figures/02_qc_read2_sequence_content.png)

**What this shows:** Per-base nucleotide frequency across all positions of Read 2.

**Interpretation:** The same bisulfite conversion signature — C depletion to ~0%, T elevation to ~50% — is confirmed in the reverse read. This validates that both strands of the library underwent complete bisulfite treatment and confirms the integrity of the paired-end data before proceeding to alignment.

---

#### Figure 3 — Methylation bias, original top strand (MethylDackel mbias)

![Methylation Bias](./01_wgbs_breast_cancer/figures/03_methylation_bias_top_strand.png)

**What this shows:** Average CpG methylation percentage as a function of read position across the original top strand.

**Interpretation:** CpG methylation is stable at 70–75% across all read positions, with no upward or downward trend at the 5′ or 3′ termini of either read. This is a critical quality checkpoint: some bisulfite library preparation protocols introduce positional bias at read ends due to end-repair artefacts or incomplete conversion near read termini, which would inflate or deflate methylation calls at those positions. The flat profile here confirms the absence of such bias and indicates that **no positional trimming is required** prior to methylation extraction. Methylation calls from all positions of all reads are therefore retained.

---

#### Figure 4 — Average methylation profile around CpG islands, single sample (plotProfile)

![Methylation Profile Single Sample](./01_wgbs_breast_cancer/figures/04_methylation_profile_single_sample.png)

**What this shows:** Average CpG methylation level relative to CpG island boundaries and associated transcription start sites (TSS) for the subset sample.

**Interpretation:** The characteristic dip in methylation centred on the TSS reflects the biologically required hypomethylation of active CpG island promoters in normal tissue. Unmethylated CpG island promoters are permissive for transcription factor binding and RNA polymerase II recruitment. Methylation of these sites leads to compaction of local chromatin and stable gene silencing. The flanking CpG island shores show intermediate methylation, consistent with the known methylation gradient around CpG islands.

---

#### Figure 5 — Average methylation profiles, all six samples (plotProfile)

![Methylation Profile All Samples](./01_wgbs_breast_cancer/figures/05_methylation_profile_all_samples.png)

**What this shows:** plotProfile output overlaying all six samples — two normal breast tissue controls (NB1, NB2) and four cancer samples (BT089, BT126, BT198, MCF7).

**Interpretation:** The TSS dip is deep and clear in normal breast tissue (NB1, NB2), reflecting intact promoter CpG island hypomethylation. In all four cancer samples, the TSS dip is **markedly attenuated** — cancer methylation levels remain elevated at the TSS rather than dipping. This indicates aberrant promoter CpG island hypermethylation in cancer, silencing genes whose promoters should be unmethylated. This pattern is the epigenomic hallmark of tumour suppressor gene silencing and is directly consistent with the findings of Lin et al. (2015), who identified widespread promoter hypermethylation-driven gene silencing in invasive ductal carcinoma.

---

#### Figure 6 — Distribution of DMR methylation differences (Metilene)

![DMR Methylation Difference Distribution](./01_wgbs_breast_cancer/figures/06_dmr_methylation_difference_distribution.png)

**What this shows:** Frequency distribution of mean methylation differences (cancer − normal) across all DMRs detected by Metilene between NB1/NB2 (normal) and BT198 (invasive ductal carcinoma).

**Interpretation:** The distribution is markedly **left-skewed**: the majority of DMRs have negative methylation differences, indicating hypomethylation in cancer relative to normal tissue. This confirms that **global hypomethylation is the dominant methylation alteration** in invasive ductal carcinoma. The smaller right-sided peak represents the biologically meaningful subset of focal promoter hypermethylation events. This bimodal pattern — bulk hypomethylation with focal hypermethylation — is the defining epigenomic feature of cancer methylomes and recapitulates the Lin et al. finding of extensive partially methylated domain (PMD) erosion in breast tumours.

---

#### Figure 7 — DMR length distribution in nucleotides

![DMR Length Nucleotides](./01_wgbs_breast_cancer/figures/07_dmr_length_nucleotides.png)

**What this shows:** Frequency distribution of detected DMR lengths in base pairs.

**Interpretation:** Most DMRs fall in the kilobase range, consistent with the scale of HMR expansions and contractions reported in the Lin et al. dataset. Shorter DMRs likely represent focal promoter or enhancer methylation changes; longer DMRs are consistent with partially methylated domain (PMD) erosion or gain spanning multi-kilobase genomic regions.

---

#### Figure 8 — DMR length distribution in CpG count

![DMR Length CpG](./01_wgbs_breast_cancer/figures/08_dmr_length_cpg_count.png)

**What this shows:** Frequency distribution of detected DMR lengths measured by number of CpG sites spanned.

**Interpretation:** The CpG-count distribution closely tracks the nucleotide-length distribution (Figure 7), as expected for regions of approximately uniform CpG spacing. The minimum CpG count requirement enforced by Metilene's segmentation algorithm ensures that all reported DMRs represent genuine multi-CpG methylation changes rather than single-CpG noise.

---

#### Figure 9 — Mean methylation difference vs q-value (Volcano-style)

![DMR QValue](./01_wgbs_breast_cancer/figures/09_dmr_qvalue_vs_difference.png)

**What this shows:** Scatter plot of mean methylation difference (x-axis) vs −log₁₀(q-value) (y-axis) for all DMRs, analogous to a methylation volcano plot.

**Interpretation:** The most significantly differentially methylated regions reach q-values below 1×10⁻¹⁰⁰ (Benjamini–Hochberg adjusted). These extreme significance values reflect the magnitude and consistency of methylation loss across cancer samples at these loci — regions where large numbers of CpGs are uniformly hypomethylated across all cancer replicates generate overwhelming statistical support. The predominantly left-sided distribution of high-significance points reinforces the dominance of hypomethylation in the cancer methylome.

---

#### Figure 10 — Group 1 vs Group 2 mean methylation scatter

![DMR Group Comparison](./01_wgbs_breast_cancer/figures/10_dmr_group1_vs_group2_methylation.png)

**What this shows:** Per-DMR mean methylation in normal breast (Group 1, x-axis) vs invasive ductal carcinoma (Group 2, y-axis). The diagonal represents no difference.

**Interpretation:** Points below the diagonal represent DMRs that are more methylated in normal tissue than in cancer — i.e., hypomethylation in cancer. Points above the diagonal represent hypermethylation in cancer. The clear predominance of points **below the diagonal** confirms global hypomethylation as the dominant change. The clustering of points along the x-axis at high normal methylation values that drop near zero in cancer is consistent with PMD erosion — regions that are fully methylated in normal cells losing their methylation in tumour cells. The smaller cluster above the diagonal represents focal promoter hypermethylation events silencing tumour suppressor genes.

---

#### Figure 11 — DMR length in nucleotides vs CpG count

![DMR Length nt vs CpG](./01_wgbs_breast_cancer/figures/11_dmr_length_nt_vs_cpg.png)

**What this shows:** Bivariate scatter of DMR nucleotide length vs CpG count for all detected DMRs.

**Interpretation:** The strong positive linear relationship is expected — longer genomic regions generally contain more CpG sites. Deviations above the trend line (more CpGs than expected for their length) identify DMRs overlapping CpG islands, which are CpG-dense relative to the genomic average. Deviations below the trend line indicate DMRs in CpG-sparse regions such as gene bodies or intergenic space, where individual CpGs are more widely spaced. This plot provides a structural characterisation of the detected DMR landscape.

---

### WGBS Summary of Findings

| Pipeline Step | Tool | Key Result | Biological Interpretation |
|---------------|------|------------|--------------------------|
| Quality Control | Falco v1.2.4 | C → ~0%, T → ~50% per-base | Complete bisulfite conversion confirmed in both reads |
| Alignment | bwameth v0.2.7 | Successful mapping to hg38 | Bisulfite-aware aligner handles C→T mismatch correctly |
| Methylation bias | MethylDackel v0.5.2 | Flat 70–75% CpG methylation across all positions | No positional artefact; full data retained without trimming |
| Methylation profiles | computeMatrix + plotProfile v3.5.4 | TSS dip attenuated in all cancer samples | Aberrant promoter CpG island hypermethylation in breast cancer |
| DMR detection | Metilene v0.2.6.1 | Left-skewed distribution; q < 1×10⁻¹⁰⁰ for top DMRs | Dominant global hypomethylation with focal hypermethylation |

> **Conclusion:** The WGBS pipeline successfully recapitulates the core epigenomic features of breast cancer described in Lin et al. (2015): a landscape of global hypomethylation — particularly in partially methylated domains — overlaid with focal promoter CpG island hypermethylation at tumour suppressor loci. These findings are consistent with the canonical cancer epigenome model and illustrate how whole-genome bisulfite sequencing can resolve these opposing changes at single-base resolution.

---

## Analysis 2 — Epigenetic Clock Benchmarking

**Platform:** Google Colab  
**Library:** Biolearn (Python)  
**Notebook:** [`02_epic_array_aging_clocks/aging_clock_benchmarking.ipynb`](./02_epic_array_aging_clocks/aging_clock_benchmarking.ipynb)  
**Full documentation:** [`02_epic_array_aging_clocks/README.md`](./02_epic_array_aging_clocks/README.md)

### Datasets

Two independent whole-blood EPIC array datasets were accessed from NCBI GEO via the Biolearn data library:

| Dataset | GEO Accession | N Samples | Platform | Description |
|---------|--------------|-----------|----------|-------------|
| Dataset 1 | **GSE120307** | 34 | Illumina EPIC 850K | Whole blood, healthy adults |
| Dataset 2 | **GSE41169** | 95 | Illumina EPIC 850K | Whole blood, healthy adults |

Using two independent datasets ensures that observed patterns (clock correlations, MAE rankings, age deviation structure) reflect genuine clock properties rather than dataset-specific sampling artefacts.

### Clocks Benchmarked

Eight aging clocks from the Biolearn model gallery were applied to both datasets:

| Clock | Year | N CpGs | Training Phenotype | Generation | Key Reference |
|-------|------|--------|--------------------|------------|---------------|
| **Horvathv1** | 2013 | 353 | Chronological age (pan-tissue) | 1st | Horvath, *Genome Biology* 2013 |
| **Hannum** | 2013 | 71 | Chronological age (blood) | 1st | Hannum et al., *Molecular Cell* 2013 |
| **Lin** | 2016 | 99 | Chronological age (blood) | 1st | Lin et al. |
| **PhenoAge** | 2018 | 513 | Composite clinical biomarkers | 2nd | Levine et al., *Aging* 2018 |
| **GrimAge** | 2019 | ~1000 | Mortality risk / DNAm surrogates | 2nd | Lu et al., *Aging* 2019 |
| **DunedinPACE** | 2022 | 173 | Longitudinal pace of physiological decline | Pace | Belsky et al., *eLife* 2022 |
| **Zhang_10** | 2019 | 10 | Chronological age (minimal set) | Minimal | Zhang et al. |
| **HRSInChPhenoAge** | 2022 | 513 | Phenotypic age (Health & Retirement Study) | 2nd | Crimmins et al. |

> **Note on DunedinPACE:** Unlike all other clocks, DunedinPACE does not output age in years. It outputs a dimensionless pace-of-aging score (population mean = 1.0), where values above 1.0 indicate faster-than-average biological aging and values below 1.0 indicate slower. Near-zero or negative correlations with chronological age clocks are therefore biologically expected and do not indicate poor performance.

### Methods

```python
from biolearn.data_library import GeoData
from biolearn.model_gallery import ModelGallery
import pandas as pd

# Load datasets
data1 = GeoData.load("GSE120307")
data2 = GeoData.load("GSE41169")

# Apply all 8 clocks
gallery = ModelGallery()
clocks = ["Horvathv1", "Hannum", "Lin", "PhenoAge",
          "GrimAge", "DunedinPACE", "Zhang_10", "HRSInChPhenoAge"]

results1, results2 = {}, {}
for clock in clocks:
    model = gallery.get(clock)
    results1[clock] = model.predict(data1).predicted_age
    results2[clock] = model.predict(data2).predicted_age

df1 = pd.DataFrame(results1)
df2 = pd.DataFrame(results2)
```

For the complete annotated code including all visualisations, see [`aging_clock_benchmarking.ipynb`](./02_epic_array_aging_clocks/aging_clock_benchmarking.ipynb).

---

### Clock Results with Interpretations

---

#### Figure 12 — Clock correlation matrix, GSE120307

![Correlation Matrix GSE120307](./02_epic_array_aging_clocks/figures/01_correlation_matrix_GSE120307.png)

**What this shows:** Pearson correlation matrix of predicted ages across all 8 clocks for 34 samples (GSE120307). Warmer colours = higher correlation.

**Interpretation:** First-generation chronological clocks (Horvathv1, Hannum, Lin) form a tight cluster with pairwise correlations exceeding r = 0.90. This is expected given their shared training objective of chronological age, despite being trained on different datasets and CpG sets. Second-generation clocks (PhenoAge, GrimAge, HRSInChPhenoAge) show moderate-to-high correlations with the first-generation group (r ≈ 0.70–0.85) but diverge from each other, reflecting different training phenotypes — phenotypic biomarkers vs mortality risk. DunedinPACE shows near-zero or negative correlations with all other clocks, consistent with its fundamentally different design: it measures the rate of biological aging, not a static age estimate, and is therefore not expected to correlate with chronological age clocks.

---

#### Figure 13 — Clock correlation matrix, GSE41169

![Correlation Matrix GSE41169](./02_epic_array_aging_clocks/figures/02_correlation_matrix_GSE41169.png)

**What this shows:** Pearson correlation matrix for 95 samples (GSE41169).

**Interpretation:** The same broad clustering structure is reproduced in the independent, larger dataset — first-generation clocks remain strongly correlated, DunedinPACE remains orthogonal. Overall correlations are modestly lower than in GSE120307, consistent with greater biological heterogeneity in the larger cohort and the wider chronological age range increasing variance. The **cross-dataset reproducibility of the correlation structure** confirms that these patterns reflect genuine biological and methodological properties of the clocks, not sampling noise from a small dataset.

---

#### Figure 14 — Age deviation heatmap, GSE120307

![Age Deviation Heatmap GSE120307](./02_epic_array_aging_clocks/figures/03_age_deviation_heatmap_GSE120307.png)

**What this shows:** Heatmap of epigenetic age deviation (predicted − chronological) per sample per clock. Each row = clock; each column = sample. Red = biological age older than chronological (positive acceleration); blue = biological age younger (negative acceleration).

**Interpretation:** The majority of first- and second-generation clocks maintain predicted ages within approximately ±10 years of chronological age, indicating reasonable calibration. Several samples show **concordant multi-clock acceleration or deceleration** — the same individual appears accelerated or decelerated across multiple independent clocks simultaneously. This pattern suggests genuine inter-individual biological age variation rather than random clock noise: when multiple clocks trained on different CpG sets and phenotypes agree about a sample's age acceleration, this is stronger evidence of true biological aging differences. Zhang_10 shows the largest deviations, reflecting the instability introduced by its minimal 10-CpG set. DunedinPACE shows systematically extreme deviations from chronological age as expected given its non-age output scale.

---

#### Figure 15 — Age deviation heatmap, GSE41169

![Age Deviation Heatmap GSE41169](./02_epic_array_aging_clocks/figures/04_age_deviation_heatmap_GSE41169.png)

**What this shows:** Age deviation heatmap for 95 samples (GSE41169).

**Interpretation:** With 95 samples, within-sample multi-clock concordance patterns are more clearly visible than in the smaller GSE120307 cohort. Distinct clusters of samples with consistent acceleration or deceleration across several first- and second-generation clocks are apparent, supporting the hypothesis that epigenetic clocks are capturing a real, shared biological aging signal. The broader absolute deviation range compared to GSE120307 reflects the wider chronological age range in this dataset, which naturally increases the magnitude of residual prediction errors at the extremes of the age distribution.

---

#### Figure 16 — Predicted vs chronological age, GSE120307

![Predicted vs Chronological Age GSE120307](./02_epic_array_aging_clocks/figures/05_predicted_vs_chronological_age_GSE120307.png)

**What this shows:** Scatter plots of predicted age (y-axis) vs chronological age (x-axis) for each clock. The red dashed diagonal represents perfect prediction.

**Interpretation:** Clocks whose points cluster tightly around the diagonal have low prediction error relative to chronological age. Horvathv1 and Hannum track chronological age most closely in this dataset. PhenoAge and GrimAge show slight systematic deviations, reflecting their training on biological phenotypes rather than chronological age — they are not optimised to minimise chronological age error. Zhang_10 shows broad scatter and poor tracking, attributable to its minimal 10-CpG set being insufficient to robustly capture the methylation signal needed for accurate age prediction. DunedinPACE points form a flat horizontal band, consistent with its output being a dimensionless pace-of-aging score uncorrelated with chronological age.

---

#### Figure 17 — Predicted vs chronological age, GSE41169

![Predicted vs Chronological Age GSE41169](./02_epic_array_aging_clocks/figures/06_predicted_vs_chronological_age_GSE41169.png)

**What this shows:** Corresponding scatter plots for the larger GSE41169 dataset (95 samples).

**Interpretation:** The broader age range in this dataset dramatically improves visual discrimination of clock accuracy across the full lifespan. Horvathv1 maintains strong linear tracking of chronological age across the entire age range. The failure of Zhang_10 is more apparent at larger sample size — predictions are scattered broadly rather than tracking the diagonal, with many predictions diverging by decades from the true age. Second-generation clocks show systematic offsets above the diagonal (predicting older biological age than chronological age), reflecting their design to capture health-related aging components that accumulate above the chronological baseline.

---

#### Figure 18 — Mean Absolute Error comparison

![MAE Comparison](./02_epic_array_aging_clocks/figures/07_mean_absolute_error_comparison.png)

**What this shows:** Bar chart of Mean Absolute Error (MAE, in years) per clock across both datasets.

**Interpretation:** **Horvathv1 achieves the lowest MAE (~4 years)** on both datasets, consistent with its status as the most extensively validated pan-tissue chronological age predictor and its training on a large, diverse multi-tissue dataset. Hannum and Lin also perform well (~5–7 years). PhenoAge and GrimAge show higher MAE (~8–12 years), which is expected since they were not optimised for minimising chronological age error — their higher MAE relative to Horvathv1 is a feature, not a flaw, reflecting that they are measuring something biologically distinct. **Zhang_10 achieves by far the highest MAE (~38 years on GSE120307)**, illustrating the substantial accuracy cost of compressing a clock to only 10 CpGs: below a critical CpG threshold, the model lacks sufficient biological signal to robustly predict age. DunedinPACE MAE in years is not directly interpretable given its dimensionless output.

---

#### Figure 19 — Predicted age distributions

![Predicted Age Distributions](./02_epic_array_aging_clocks/figures/08_predicted_age_distributions.png)

**What this shows:** Box plots of predicted age distributions per clock for both datasets.

**Interpretation:** First-generation and second-generation clocks produce predicted age distributions broadly centred on each cohort's mean chronological age, as expected for well-calibrated predictors trained on populations with similar age demographics. The inter-quartile ranges of well-performing clocks reflect the genuine spread of biological ages within the cohorts. **Zhang_10 is a clear outlier**: on GSE120307, its median prediction falls near zero years, indicating severe miscalibration on this dataset. This confirms that Zhang_10's 10-CpG architecture cannot generalise reliably across datasets, likely due to overfitting to its training cohort. DunedinPACE shows a compressed distribution near its expected mean of 1.0, confirming its distinct output scale and internally consistent predictions.

---

### Clock Summary of Findings

| Metric | Best Performer | Worst Performer | Key Observation |
|--------|---------------|-----------------|-----------------|
| Chronological age accuracy (MAE) | **Horvathv1** (~4 yr) | **Zhang_10** (~38 yr) | CpG count strongly influences prediction accuracy |
| Inter-clock agreement | Horvathv1 / Hannum / Lin (r > 0.90) | DunedinPACE | DunedinPACE is conceptually and statistically orthogonal |
| Age deviation stability | Lin, Hannum (within ±10 yr) | Zhang_10, DunedinPACE | Non-chronological clocks show largest deviations by design |
| Cross-dataset reproducibility | All 1st/2nd generation clocks | — | Clock behaviour is stable and replicable across independent datasets |

> **Conclusion:** First-generation chronological clocks — particularly Horvathv1 — remain the most accurate predictors of chronological age in blood methylation data. Second-generation clocks (PhenoAge, GrimAge) provide complementary information about biological aging and health risk at the cost of increased chronological prediction error. DunedinPACE offers a fundamentally orthogonal perspective on aging pace not captured by static age-prediction models. Zhang_10 demonstrates that extreme CpG compression sacrifices prediction accuracy to the point of clinical inutility, highlighting the importance of adequate CpG representation in robust clock design.

---

## How to Reproduce

### Analysis 1 — WGBS (Galaxy Europe)

1. Navigate to [https://usegalaxy.eu](https://usegalaxy.eu) and create a free account
2. Follow the [Galaxy Training Network DNA Methylation tutorial](https://training.galaxyproject.org/training-material/topics/epigenetics/tutorials/methylation-seq/tutorial.html)
3. Import the Lin et al. dataset from ArrayExpress accession **E-MTAB-2014**
4. Apply tools in the pipeline order above (versions specified in the Dependencies table)

### Analysis 2 — EPIC Array (Google Colab)

1. Open [`aging_clock_benchmarking.ipynb`](./02_epic_array_aging_clocks/aging_clock_benchmarking.ipynb) in Google Colab
2. Install the Biolearn library:
   ```bash
   pip install biolearn pandas numpy matplotlib seaborn
   ```
3. Run all cells — datasets are fetched automatically from NCBI GEO via `GeoData.load()`

---

## Dependencies

### Analysis 1 — Galaxy Europe

| Tool | Version | Purpose |
|------|---------|---------|
| Falco | 1.2.4 | Read quality control and bisulfite conversion verification |
| bwameth | 0.2.7 | Bisulfite-aware short-read alignment to hg38 |
| MethylDackel | 0.5.2 | Per-CpG methylation extraction and bias assessment |
| computeMatrix | 3.5.4 | Signal matrix construction around genomic features |
| plotProfile | 3.5.4 | Methylation profile visualisation across samples |
| Metilene | 0.2.6.1 | Differentially methylated region detection |

### Analysis 2 — Python (Google Colab)

```bash
pip install biolearn pandas numpy matplotlib seaborn
```

| Package | Purpose |
|---------|---------|
| biolearn | Epigenetic clock models and GEO data access |
| pandas | Data manipulation and clock prediction aggregation |
| numpy | Numerical operations |
| matplotlib | Figure generation |
| seaborn | Heatmaps and correlation matrices |

---

## Citations

1. **Lin et al. (2015).** Hierarchical Clustering of Breast Cancer Methylomes Revealed Differentially Methylated and Expressed Breast Cancer Genes. *PLOS ONE*, 10(2), e0118453. https://doi.org/10.1371/journal.pone.0118453

2. **Ying, K. et al. (2023).** Biolearn, an open-source library for biomarkers of aging. *bioRxiv*. https://doi.org/10.1101/2023.12.02.569722

3. **Horvath, S. (2013).** DNA methylation age of human tissues and cell types. *Genome Biology*, 14, R115. https://doi.org/10.1186/gb-2013-14-10-r115

4. **Hannum, G. et al. (2013).** Genome-wide methylation profiles reveal quantitative views of human aging rates. *Molecular Cell*, 49(2), 359–367. https://doi.org/10.1016/j.molcel.2012.10.016

5. **Levine, M.E. et al. (2018).** An epigenetic biomarker of aging for lifespan and healthspan. *Aging*, 10(4), 573–591. https://doi.org/10.18632/aging.101414

6. **Lu, A.T. et al. (2019).** DNA methylation GrimAge strongly predicts lifespan and healthspan. *Aging*, 11(2), 303–327. https://doi.org/10.18632/aging.101684

7. **Belsky, D.W. et al. (2022).** DunedinPACE, a DNA methylation biomarker of the pace of aging. *eLife*, 11, e73420. https://doi.org/10.7554/eLife.73420

8. **Wolff, J., Ryan, D., Moosmann, V. (2017).** DNA Methylation data analysis. *Galaxy Training Materials*. https://training.galaxyproject.org/training-material/topics/epigenetics/tutorials/methylation-seq/tutorial.html

---

## License

This project is licensed under the MIT License. See [LICENSE](LICENSE) for details.
